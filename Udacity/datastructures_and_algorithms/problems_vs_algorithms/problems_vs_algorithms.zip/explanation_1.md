Time efficiency
O(logn) - using binary search to reduce the problem size in half

Space efficiency
O(1) - no extra space used