
Design Choice and DS Algo used With Brief Explanation:
- Binary search to reduce the problem size in half each time

Big(O) Time with a brief explanation, mention what is N
- O(logN) - N is the number, without binary search it will take N iterations

Big(O) Space with a brief explanation, mention what is N and Call stack for recursive solutions
- O(1) constant space complexity