Design Choice and DS Algo used With Brief Explanation:
- I used a trie to solve the problem

Big(O) Time with a brief explanation, mention what is N
- Time complexity:
- insert - O(n) 
- suffixes - O(k)
- find - O(n)
- n is the length of the word, k is the length of the prefix

Big(O) Space with a brief explanation, mention what is N and Call stack for recursive solutions
- insert - O(n) n is the number of characters in word
- suffixes - O(1) constant space complexity
- find - O(1) constant space complexity