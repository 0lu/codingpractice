Time complexity:
insert - O(n) 
suffixes - O(k)
find - O(n)

n - length of the word to be inserted or found
k - total length of all suffixes of that prefix

Space complexity
O(1)

I used a trie to solve the problem