Time complexity:
O(n)

Space complexity:
O(1)

