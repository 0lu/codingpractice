Design Choice and DS Algo used With Brief Explanation:
- I used a varation of binary search for the problem. Normally in binary
search we go left if the mid is greater than what we are looking for but
in this case we check if we are in the unshifted part first and go the normal
direction if not we switch directions

Big(O) Time with a brief explanation, mention what is N
- O(logN) - N is the size of the array

Big(O) Space with a brief explanation, mention what is N and Call stack for recursive solutions
- O(1) constant space complexity