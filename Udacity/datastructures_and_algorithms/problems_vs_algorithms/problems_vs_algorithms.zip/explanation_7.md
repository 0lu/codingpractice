Time complexity:
insert - O(n)
find - O(n)

n = length of the path after spliting by /

Space complexity:
O(n) - total number of paths in the trie