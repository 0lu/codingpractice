Design Choice and DS Algo used With Brief Explanation:
- I used a trie to solve the problem

Big(O) Time with a brief explanation, mention what is N
- insert - O(n)
- find - O(n)
- n = length of the path after splitting by /

Big(O) Space with a brief explanation, mention what is N and Call stack for recursive solutions
- insert - O(n) n is the length of path after splitting by /
- find - O(1) constant space 