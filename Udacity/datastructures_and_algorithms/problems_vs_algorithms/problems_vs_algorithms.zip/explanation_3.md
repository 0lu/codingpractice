Time complexity:
O(n) - heapify
O(nlogn) - pop all from heap
Overall - O(nlogn)

Space complexity:
O(1) - No additional space

I used a max heap to store the elements and used a greedy approach to pick
the largest element each time and add to the numbers.