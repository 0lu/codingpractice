
Design Choice and DS Algo used With Brief Explanation:
- I used a 2 pointer approach keeping one for swapping 0s, one for swapping
2s.

Big(O) Time with a brief explanation, mention what is N
- O(n) - n is the length of the array

Big(O) Space with a brief explanation, mention what is N and Call stack for recursive solutions
- O(1) constant space complexity