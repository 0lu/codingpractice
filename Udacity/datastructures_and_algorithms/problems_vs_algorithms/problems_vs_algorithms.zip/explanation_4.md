Time complexity:
O(n) - one pass

Space complexity:
O(1) - in place

I used a 2 pointer approach keeping one for swapping 0s, one for swapping
2s.