Time Complexity:
calc hash - O(1)
insert node - O(1)

Space Complexity:
O(1) - no additional space required

I used a linked list to chain the block nodes together