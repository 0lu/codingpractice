Time Complexity:
calc hash - O(1)
insert node - O(1)

Space Complexity:
O(n) - Which grows as the input size grows

I used a linked list to chain the block nodes together